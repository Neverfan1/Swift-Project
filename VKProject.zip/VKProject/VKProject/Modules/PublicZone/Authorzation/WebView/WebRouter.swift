//
//  WebRouter.swift
//  VKProject
//
//  Created by Данила Парамин on 20.08.2022.
//

import Foundation

protocol WebRouter: AnyObject {

}


