//
//  VKProjectApp.swift
//  VKProject
//
//  Created by Данила Парамин on 10.08.2022.
//

import SwiftUI

@main
struct VKProjectApp: App {
    var body: some Scene {
        WindowGroup {
            MainCoordinator().view()
//            ContentView()

        }
    }
}
